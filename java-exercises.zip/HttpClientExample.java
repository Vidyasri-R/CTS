import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HttpClientExample {
    public static void main(String[] args) {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.github.com/"))
                .header("Accept", "application/vnd.github.v3+json")
                .GET()
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("Response Status Code: " + response.statusCode());
            System.out.println("Response Headers: " + response.headers());
            System.out.println("Response Body (Truncated):");
            if (response.body() != null && response.body().length() > 500) {
                System.out.println(response.body().substring(0, 500) + "...");
            } else {
                System.out.println(response.body());
            }
        } catch (Exception e) {
            System.out.println("Request failed: " + e.getMessage());
        }
    }
}
