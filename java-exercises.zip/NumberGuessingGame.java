import java.util.Scanner;
import java.util.Random;

public class NumberGuessingGame {
    public static void main(String[] args) {
        Random rand = new Random();
        int target = rand.nextInt(100) + 1;
        Scanner sc = new Scanner(System.in);
        int guess = 0;
        int attempts = 0;

        System.out.println("Guess the number between 1 and 100!");
        while (guess != target) {
            System.out.print("Your guess: ");
            guess = sc.nextInt();
            attempts++;
            if (guess < target) System.out.println("Too low! Try again.");
            else if (guess > target) System.out.println("Too high! Try again.");
            else System.out.println("Correct! You guessed it in " + attempts + " attempts.");
        }
        sc.close();
    }
}
