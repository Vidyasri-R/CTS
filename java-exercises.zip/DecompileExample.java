public class DecompileExample {
    public static void main(String[] args) {
        System.out.println("=== Decompiler Tool Guide ===");
        System.out.println("Decompilation retrieves Java source code from a compiled .class file.");
        System.out.println("Recommended Decompilers:");
        System.out.println("1. JD-GUI (Graphical Interface decompiler)");
        System.out.println("2. CFR (Command-line decompiler)");
        System.out.println("   Run command: java -jar cfr.jar DecompileExample.class");
        System.out.println("3. Fernflower (Built into IntelliJ IDEA)");
        System.out.println("Try compiling this file and loading the .class into any decompiler tool.");
    }
}
