import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TransactionHandling {
    static Connection getConnection() throws Exception {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/community_portal", "root", "your_password");
    }

    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = getConnection();
            conn.setAutoCommit(false);

            String withdrawSql = "UPDATE accounts SET balance = balance - ? WHERE account_id = ?";
            try (PreparedStatement ps1 = conn.prepareStatement(withdrawSql)) {
                ps1.setDouble(1, 500.0);
                ps1.setInt(2, 1);
                ps1.executeUpdate();
            }

            String depositSql = "UPDATE accounts SET balance = balance + ? WHERE account_id = ?";
            try (PreparedStatement ps2 = conn.prepareStatement(depositSql)) {
                ps2.setDouble(1, 500.0);
                ps2.setInt(2, 2);
                ps2.executeUpdate();
            }

            conn.commit();
            System.out.println("Transaction committed successfully!");
        } catch (Exception e) {
            System.out.println("Transaction failed. Rolling back changes. Error: " + e.getMessage());
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }
}
