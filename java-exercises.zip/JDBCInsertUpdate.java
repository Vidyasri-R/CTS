import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class JDBCInsertUpdate {
    static Connection getConnection() throws Exception {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/community_portal", "root", "your_password");
    }

    static void insertStudent(String name, String email, String city) {
        String sql = "INSERT INTO Users (full_name, email, city, registration_date) VALUES (?, ?, ?, CURDATE())";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, city);
            int rows = ps.executeUpdate();
            System.out.println(rows + " row(s) inserted.");
        } catch (Exception e) {
            System.out.println("Insert error: " + e.getMessage());
        }
    }

    static void updateStudent(int id, String newName) {
        String sql = "UPDATE Users SET full_name = ? WHERE user_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newName);
            ps.setInt(2, id);
            int rows = ps.executeUpdate();
            System.out.println(rows + " row(s) updated.");
        } catch (Exception e) {
            System.out.println("Update error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        insertStudent("Frank Wilson", "frank@example.com", "Houston");
        updateStudent(1, "Alice Johnson Updated");
    }
}
