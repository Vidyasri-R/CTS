import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPChatServer {
    public static void main(String[] args) {
        System.out.println("Starting chat server on port 5000...");
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected!");

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
            String clientMsg, serverMsg;

            while ((clientMsg = in.readLine()) != null) {
                System.out.println("Client: " + clientMsg);
                if (clientMsg.equalsIgnoreCase("exit")) {
                    out.println("Goodbye!");
                    break;
                }
                System.out.print("Server: ");
                serverMsg = kb.readLine();
                out.println(serverMsg);
            }
        } catch (Exception e) {
            System.out.println("Server exception: " + e.getMessage());
        }
    }
}
