import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BasicJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/community_portal";
        String user = "root";
        String password = "your_password";

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to database!");

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Users");

            System.out.println("ID\tName\t\tEmail\t\t\tCity");
            System.out.println("--\t----\t\t-----\t\t\t----");
            while (rs.next()) {
                System.out.println(rs.getInt("user_id") + "\t" +
                        rs.getString("full_name") + "\t" +
                        rs.getString("email") + "\t" +
                        rs.getString("city"));
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
