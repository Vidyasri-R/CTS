import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class ReflectionExample {
    public void printMessage(String msg) {
        System.out.println("Reflection invoked: " + msg);
    }

    public static void main(String[] args) {
        try {
            Class<?> clazz = Class.forName("ReflectionExample");
            Constructor<?> constructor = clazz.getConstructor();
            Object instance = constructor.newInstance();

            Method method = clazz.getMethod("printMessage", String.class);
            method.invoke(instance, "Dynamic Execution Success!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
