public class PatternMatchingSwitch {
    static String checkType(Object obj) {
        return switch (obj) {
            case Integer i -> "Integer with value: " + i;
            case String s -> "String with value: \"" + s + "\" (length: " + s.length() + ")";
            case Double d -> "Double with value: " + d;
            case Long l -> "Long with value: " + l;
            case null -> "Null value";
            default -> "Unknown type: " + obj.getClass().getSimpleName();
        };
    }

    public static void main(String[] args) {
        System.out.println(checkType(42));
        System.out.println(checkType("Hello Java 21"));
        System.out.println(checkType(3.14));
        System.out.println(checkType(100L));
        System.out.println(checkType(null));
        System.out.println(checkType(true));
    }
}
