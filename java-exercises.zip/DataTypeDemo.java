public class DataTypeDemo {
    public static void main(String[] args) {
        int age = 25;
        float salary = 45000.50f;
        double pi = 3.14159265;
        char grade = 'A';
        boolean isActive = true;

        System.out.println("int: " + age);
        System.out.println("float: " + salary);
        System.out.println("double: " + pi);
        System.out.println("char: " + grade);
        System.out.println("boolean: " + isActive);
    }
}
