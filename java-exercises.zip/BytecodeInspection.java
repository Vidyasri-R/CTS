public class BytecodeInspection {
    public int add(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        System.out.println("=== Bytecode Inspection Guide ===");
        System.out.println("Compile this class:");
        System.out.println("   javac BytecodeInspection.java");
        System.out.println("Inspect the generated JVM bytecode instruction set using javap:");
        System.out.println("   javap -c BytecodeInspection");
        System.out.println("Output will display JVM operations like iload_1, iload_2, iadd, ireturn.");
    }
}
