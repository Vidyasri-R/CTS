public class ModuleExample {
    public static void main(String[] args) {
        System.out.println("=== Java Platform Module System (JPMS) Guide ===");
        System.out.println("To create a module:");
        System.out.println("1. Create a file named 'module-info.java' in your root source directory:");
        System.out.println("   module com.example.myhelper {");
        System.out.println("       exports com.example.utils;");
        System.out.println("   }");
        System.out.println("2. Compile the module using module paths:");
        System.out.println("   javac -d out --module-source-path src $(find src -name '*.java')");
        System.out.println("3. Run the module application:");
        System.out.println("   java --module-path out --module com.example.myhelper/com.example.utils.Main");
    }
}
