import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LambdaExpressions {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Charlie", "Alice", "Ethan", "Bob", "Diana");
        System.out.println("Before sorting: " + names);
        Collections.sort(names, (a, b) -> a.compareTo(b));
        System.out.println("After sorting (ascending): " + names);
        Collections.sort(names, (a, b) -> b.compareTo(a));
        System.out.println("After sorting (descending): " + names);
    }
}
