public class CarDemo {
    String make;
    String model;
    int year;

    CarDemo(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    void displayDetails() {
        System.out.println("Make: " + make + ", Model: " + model + ", Year: " + year);
    }

    public static void main(String[] args) {
        CarDemo car1 = new CarDemo("Toyota", "Camry", 2023);
        CarDemo car2 = new CarDemo("Honda", "Civic", 2024);
        CarDemo car3 = new CarDemo("Tesla", "Model 3", 2025);
        car1.displayDetails();
        car2.displayDetails();
        car3.displayDetails();
    }
}
