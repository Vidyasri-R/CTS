public class OperatorPrecedence {
    public static void main(String[] args) {
        int result1 = 10 + 5 * 2;
        System.out.println("10 + 5 * 2 = " + result1 + " (multiplication first)");

        int result2 = (10 + 5) * 2;
        System.out.println("(10 + 5) * 2 = " + result2 + " (parentheses first)");

        int result3 = 20 - 4 / 2 + 3;
        System.out.println("20 - 4 / 2 + 3 = " + result3 + " (division first, then left to right)");

        int result4 = 10 % 3 + 2 * 4;
        System.out.println("10 % 3 + 2 * 4 = " + result4 + " (% and * first, then +)");

        boolean result5 = 5 > 3 && 10 < 20;
        System.out.println("5 > 3 && 10 < 20 = " + result5 + " (comparison first, then &&)");
    }
}
