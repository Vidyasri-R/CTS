public class TypeCastingExample {
    public static void main(String[] args) {
        double myDouble = 9.78;
        int myInt = (int) myDouble;
        System.out.println("Double value: " + myDouble);
        System.out.println("After casting to int: " + myInt);

        int anotherInt = 15;
        double anotherDouble = (double) anotherInt;
        System.out.println("Int value: " + anotherInt);
        System.out.println("After casting to double: " + anotherDouble);
    }
}
