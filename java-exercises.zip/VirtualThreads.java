public class VirtualThreads {
    public static void main(String[] args) throws InterruptedException {
        long startTime = System.currentTimeMillis();

        Thread vThread = Thread.startVirtualThread(() -> {
            System.out.println("Running task inside virtual thread: " + Thread.currentThread());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        vThread.join();
        long duration = System.currentTimeMillis() - startTime;
        System.out.println("Execution finished in " + duration + " ms.");
    }
}
