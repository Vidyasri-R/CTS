import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TCPChatClient {
    public static void main(String[] args) {
        System.out.println("Connecting to chat server on localhost:5000...");
        try (Socket socket = new Socket("localhost", 5000)) {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
            String clientMsg, serverMsg;

            while (true) {
                System.out.print("Client: ");
                clientMsg = kb.readLine();
                out.println(clientMsg);
                if (clientMsg.equalsIgnoreCase("exit")) {
                    break;
                }
                serverMsg = in.readLine();
                System.out.println("Server: " + serverMsg);
            }
        } catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
        }
    }
}
